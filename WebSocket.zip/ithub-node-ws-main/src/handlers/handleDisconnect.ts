import type { DisconnectOptions } from "../types"

export default function handleDisconnect({ connections, newUserId }: DisconnectOptions) {
    connections.delete(newUserId)
}

wss.on('connection', (ws) => {  
    console.log('Пользователь подключён');  
    ws.on('close', () => {  
        console.log('Пользователь отключён');  
    });  
});  
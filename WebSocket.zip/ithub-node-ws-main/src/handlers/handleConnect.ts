import { randomUUID } from 'node:crypto'

import { messages } from '../storage'
import type { Message, ConnectOptions } from '../types'


export default function handleConnect({ connections, connection }: ConnectOptions) {
    const newUserId = randomUUID()
    // TODO: генерация ID в стиле нелепая-обезьяна, deprecated-being

    const adjectives = [
        'ridiculous', 'funny', 'dancing', 'sleepy', 'hungry', 'fluffy',
        'elegant', 'pensive', 'cunning', 'loud', 'quiet', 'fast',
        'slow', 'joyful', 'sad', 'colorful', 'shiny'
    ];

    const animals = [
        'monkey', 'whale', 'dolphin', 'raccoon', 'panda', 'lemur', 'platypus',
        'narwhal', 'axolotl', 'tapir', 'mongoose', 'capybara', 'possum',
        'porcupine', 'beaver', 'meerkat'
    ];

    const verbs = [
        'eating', 'playing', 'sleeping', 'running', 'swimming', 'flying', 'reading',
        'programming', 'singing', 'dancing', 'watching', 'building', 'drawing'
    ];

    const objects = [
        'banana', 'book', 'ball', 'computer', 'guitar', 'telescope', 'cake',
        'balloon', 'puzzle', 'scooter', 'ice cream', 'sushi'
    ];

    function getRandomElement(array) {
        return array[Math.floor(Math.random() * array.length)];
    }

    function generateSillyWhaleId() {
        const adjective = getRandomElement(adjectives);
        const animal = getRandomElement(animals);
        const verb = getRandomElement(verbs);
        const object = getRandomElement(objects);

        return `${adjective}-${animal}-${verb}-${object}`;
    }

    module.exports = {
        generateSillyWhaleId,
        wordLists: {
            adjectives,
            animals,
            verbs,
            objects
        }
    };

    connections.set(newUserId, connection)

    const userJoinObject: Message = {
        type: "user:join",
        payload: newUserId
    }

    for (const userConnection of connections.values()) {
        userConnection.send(JSON.stringify(userJoinObject))
    }

    const messagesObject: Message = {
        type: "messages",
        payload: messages
    }

    const usersObject: Message = {
        type: "users",
        payload: [...connections.keys()]
    }

    connection.send(JSON.stringify(messagesObject))
    connection.send(JSON.stringify(usersObject))

    return newUserId

}
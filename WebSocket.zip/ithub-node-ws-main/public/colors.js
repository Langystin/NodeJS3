const colors = require('@larchanka/colors-js');

console.log(green('Успех!'));
console.log(red('Ошибка!'));
console.log(yellow('Предупреждение!'));
console.log(bgPurple('Это сообщение имеет фиолетовый фон'));